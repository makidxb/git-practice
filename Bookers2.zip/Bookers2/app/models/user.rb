class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_many :books, dependent: :destroy
  attachment :profile_image

  validates :name, presence: { message: "Error : Name is too short, minimum is 2 characters" }, length: { minimum: 2 }
  validates :introduction, presence: { message: "Error : Introduction is too long (max 50 characters)." }, length: { maximum: 50 }

end
