class Book < ApplicationRecord
  validates :title, presence: { message: "Error : Title cannot be blank" }
  validates :body, presence: {message: "Error : Body cannot be blank" }
end
